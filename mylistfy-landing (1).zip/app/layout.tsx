import type React from "react"
import "./globals.css"
import type { Metadata } from "next"
import { Inter } from "next/font/google"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Com a MyListfy é menos tempo e mais lucro",
  description:
    "Você está pronto para aumentar seus lucros na Amazon vendendo FBA ou FBM? A MyListfy traz diariamente os produtos para você escolher, listar e lucrar. Nossa lista simplifica tudo para você!",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR">
      <body className={inter.className}>{children}</body>
    </html>
  )
}


import './globals.css'