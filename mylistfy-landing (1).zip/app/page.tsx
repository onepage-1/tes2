import NextImage from "next/image"
import { Montserrat } from "next/font/google"
import Hero from "@/components/hero"
import Features from "@/components/features"
import Benefits from "@/components/benefits"
import Suppliers from "@/components/suppliers"
import ListDetails from "@/components/list-details"
import UniqueFeatures from "@/components/unique-features"
import Reviews from "@/components/reviews"
import Pricing from "@/components/pricing"
import FAQ from "@/components/faq"
import CTA from "@/components/cta"
import Footer from "@/components/footer"

const montserrat = Montserrat({ subsets: ["latin"] })

export default function Home() {
  return (
    <main className={`${montserrat.className} min-h-screen`}>
      <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-sm shadow-sm">
        <div className="container mx-auto px-4 py-2 flex justify-between items-center">
          <div className="flex items-center">
            <NextImage src="/images/logo.png" alt="MyListfy Logo" width={300} height={85} className="h-16 w-auto" />
          </div>
          <nav className="hidden md:flex space-x-8">
            <a href="#features" className="text-gray-800 hover:text-[#4fffbd] transition-colors">
              Recursos
            </a>
            <a href="#benefits" className="text-gray-800 hover:text-[#4fffbd] transition-colors">
              Benefícios
            </a>
            <a href="#suppliers" className="text-gray-800 hover:text-[#4fffbd] transition-colors">
              Fornecedores
            </a>
            <a href="#unique-features" className="text-gray-800 hover:text-[#4fffbd] transition-colors">
              Diferenciais
            </a>
            <a href="#reviews" className="text-gray-800 hover:text-[#4fffbd] transition-colors">
              Depoimentos
            </a>
            <a href="#pricing" className="text-gray-800 hover:text-[#4fffbd] transition-colors">
              Preços
            </a>
          </nav>
          <a
            href="#pricing"
            className="bg-gradient-to-r from-[#4fffbd] to-[#88ffff] text-gray-800 font-medium px-6 py-2 rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-105 transform duration-200"
          >
            Assinar Agora
          </a>
        </div>
      </header>

      <Hero />
      <Features />
      <Benefits />
      <Suppliers />
      <ListDetails />
      <UniqueFeatures />
      <Reviews />
      <Pricing />
      <FAQ />
      <CTA />
      <Footer />
    </main>
  )
}
