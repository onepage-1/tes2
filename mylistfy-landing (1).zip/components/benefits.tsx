import { DollarSign, TrendingUp, BarChart3 } from "lucide-react"

export default function Benefits() {
  return (
    <section id="benefits" className="py-20 bg-gradient-to-br from-[#4fffbd]/15 to-[#88ffff]/15">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 relative inline-block">
            Benefícios da MyListfy
            <div className="absolute -bottom-2 left-0 right-0 h-1 bg-gradient-to-r from-[#4fffbd] to-[#88ffff] rounded-full"></div>
          </h2>
          <p className="text-lg text-gray-600">
            Descubra como nossa lista de produtos pode transformar seu negócio na Amazon.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div className="order-2 md:order-1">
            <div className="space-y-8">
              <div className="flex gap-4 transition-all duration-300 hover:translate-x-2">
                <div className="flex-shrink-0 w-12 h-12 bg-[#4fffbd] rounded-full flex items-center justify-center text-2xl font-bold shadow-md">
                  1
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Reduza seus custos operacionais</h3>
                  <p className="text-gray-600">
                    Economize com softwares caros e assistentes virtuais. Nossa lista substitui a necessidade de
                    múltiplas ferramentas e funcionários.
                  </p>
                </div>
              </div>

              <div className="flex gap-4 transition-all duration-300 hover:translate-x-2">
                <div className="flex-shrink-0 w-12 h-12 bg-[#88ffff] rounded-full flex items-center justify-center text-2xl font-bold shadow-md">
                  2
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Aumente sua eficiência</h3>
                  <p className="text-gray-600">
                    Receba produtos pré-selecionados diariamente, permitindo que você foque apenas em comprar e vender,
                    sem perder tempo com pesquisas.
                  </p>
                </div>
              </div>

              <div className="flex gap-4 transition-all duration-300 hover:translate-x-2">
                <div className="flex-shrink-0 w-12 h-12 bg-[#4fffbd] rounded-full flex items-center justify-center text-2xl font-bold shadow-md">
                  3
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Maximize seus lucros</h3>
                  <p className="text-gray-600">
                    Com produtos de alto ROI e vendas consistentes, você maximiza seus lucros e aumenta o giro do seu
                    capital.
                  </p>
                </div>
              </div>

              <div className="flex gap-4 transition-all duration-300 hover:translate-x-2">
                <div className="flex-shrink-0 w-12 h-12 bg-[#88ffff] rounded-full flex items-center justify-center text-2xl font-bold shadow-md">
                  4
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Escale seu negócio</h3>
                  <p className="text-gray-600">
                    Com produtos confiáveis e consistentes, você pode escalar seu negócio na Amazon de forma segura e
                    previsível.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="order-1 md:order-2 relative">
            <div className="bg-[#fff0df] rounded-3xl p-8 shadow-2xl relative z-10 transition-all duration-300 hover:shadow-xl hover:translate-y-[-8px]">
              <div className="space-y-6">
                <div className="flex items-center justify-between border-b border-amber-200 pb-4">
                  <div>
                    <h4 className="text-2xl font-bold">$12</h4>
                    <p className="text-sm text-gray-500">
                      O lucro médio dos leads na lista MyListfy é de até $12. O mínimo é $5.
                    </p>
                  </div>
                  <div className="bg-gradient-to-r from-[#4fffbd] to-[#88ffff] p-3 rounded-full shadow-md">
                    <DollarSign className="h-6 w-6" />
                  </div>
                </div>

                <div className="flex items-center justify-between border-b border-amber-200 pb-4">
                  <div>
                    <h4 className="text-2xl font-bold">75% ROI</h4>
                    <p className="text-sm text-gray-500">Terá até 75% de ROI médio com nossos produtos.</p>
                  </div>
                  <div className="bg-gradient-to-r from-[#4fffbd] to-[#88ffff] p-3 rounded-full shadow-md">
                    <TrendingUp className="h-6 w-6" />
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-2xl font-bold">Média de 100 Vendas mensais</h4>
                    <p className="text-sm text-gray-500">
                      Os produtos realizam em média 100 vendas mensais, com um mínimo de 10 vendas.
                    </p>
                  </div>
                  <div className="bg-gradient-to-r from-[#4fffbd] to-[#88ffff] p-3 rounded-full shadow-md">
                    <BarChart3 className="h-6 w-6" />
                  </div>
                </div>
              </div>
            </div>
            <div className="absolute -bottom-6 -right-6 w-64 h-64 bg-[#4fffbd]/30 rounded-full blur-3xl -z-10 animate-pulse"></div>
            <div className="absolute -top-6 -left-6 w-64 h-64 bg-[#88ffff]/30 rounded-full blur-3xl -z-10 animate-pulse"></div>
          </div>
        </div>
      </div>
    </section>
  )
}
