export default function CTA() {
  return (
    <section className="py-20 bg-gradient-to-r from-[#4fffbd] to-[#88ffff]">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-800">
            Pronto para aumentar seus lucros na Amazon?
          </h2>
          <p className="text-xl mb-8 text-gray-700">
            Junte-se a centenas de vendedores brasileiros que estão transformando seus negócios com a MyListfy.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="#pricing"
              className="bg-gray-800 text-white font-bold px-8 py-3 rounded-full shadow-lg hover:shadow-xl transition-all text-lg hover:scale-105 transform duration-200"
            >
              Começar Agora
            </a>
            <a
              href="#"
              className="bg-white text-gray-800 font-medium px-8 py-3 rounded-full shadow border border-gray-200 hover:shadow-md transition-all text-lg hover:bg-gray-50"
            >
              Falar com um Consultor
            </a>
          </div>
          <p className="mt-6 text-sm text-gray-700">Assine e comece hoje mesmo a lucrar com a nossa lista!</p>
        </div>
      </div>
    </section>
  )
}
