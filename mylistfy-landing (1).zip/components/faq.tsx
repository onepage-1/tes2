"use client"

import { useState } from "react"
import { ChevronDown, ChevronUp } from "lucide-react"

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState(0)

  const faqs = [
    {
      question: "Como funciona a lista de produtos da MyListfy?",
      answer:
        "Chegará por e-mail o arquivo em excel todos os dias com todos os produtos analisados, só será necessário comprar no fornecedor e enviar para o seu prep center. Cada produto vem com todas as informações necessárias para você tomar a decisão de compra, incluindo preço de compra, preço de venda, lucro estimado, ROI e histórico de vendas.",
    },
    {
      question: "Qual é o lucro médio dos produtos na lista?",
      answer:
        "Os produtos na nossa lista têm um lucro médio de $12, com um mínimo garantido de $5 por produto. O ROI médio é de até 75%, garantindo um excelente retorno sobre seu investimento.",
    },
    {
      question: "Quantos produtos são enviados diariamente?",
      answer:
        "Enviamos entre 10 a 15 produtos lucrativos diariamente, de segunda a sexta-feira. Todos os produtos são cuidadosamente selecionados pela nossa equipe para garantir qualidade e lucratividade.",
    },
    {
      question: "Preciso ter experiência vendendo na Amazon?",
      answer:
        "Não é necessário ter experiência prévia, mas é recomendado que você tenha conhecimentos básicos sobre como vender na Amazon dos EUA. Oferecemos suporte para ajudar iniciantes a entenderem como aproveitar ao máximo nossa lista.",
    },
    {
      question: "Os produtos funcionam tanto para FBA quanto para FBM?",
      answer:
        "Sim, nossa lista inclui produtos que funcionam bem tanto para o modelo FBA (Fulfillment by Amazon) quanto para o FBM (Fulfillment by Merchant), permitindo que você escolha a estratégia que melhor se adapta ao seu negócio.",
    },
    {
      question: "Como posso confiar na MyListfy?",
      answer:
        "A MyListfy trabalha desde 2023 fornecendo listas com os melhores produtos (deals) do mercado. Nossa equipe tem vasta experiência em Online Arbitrage na Amazon e seleciona cuidadosamente cada produto para garantir a melhor qualidade e lucratividade para nossos clientes.",
    },
  ]

  return (
    <section id="faq" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 relative inline-block">
            Perguntas Frequentes
            <div className="absolute -bottom-2 left-0 right-0 h-1 bg-gradient-to-r from-[#4fffbd] to-[#88ffff] rounded-full"></div>
          </h2>
          <p className="text-lg text-gray-600 mb-4">Tire suas dúvidas sobre a MyListfy e nossos serviços.</p>
        </div>

        <div className="max-w-3xl mx-auto bg-[#fff0df] rounded-3xl p-6 md:p-8 shadow-lg">
          {faqs.map((faq, index) => (
            <div key={index} className={`${index !== 0 ? "border-t border-amber-200" : ""} py-4`}>
              <button
                className="flex justify-between items-center w-full text-left font-medium text-lg"
                onClick={() => setOpenIndex(openIndex === index ? -1 : index)}
              >
                <span className="pr-8">{faq.question}</span>
                <div
                  className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center transition-colors ${openIndex === index ? "bg-[#4fffbd]" : "bg-white border border-amber-200"}`}
                >
                  {openIndex === index ? (
                    <ChevronUp className="h-5 w-5 text-white" />
                  ) : (
                    <ChevronDown className="h-5 w-5 text-gray-500" />
                  )}
                </div>
              </button>
              <div
                className={`mt-2 transition-all duration-300 overflow-hidden ${openIndex === index ? "max-h-96 opacity-100" : "max-h-0 opacity-0"}`}
              >
                <div className="pt-2 pb-1 text-gray-700 bg-white/50 p-4 rounded-lg">{faq.answer}</div>
              </div>
            </div>
          ))}
        </div>

        <div className="max-w-3xl mx-auto mt-8 text-center">
          <p className="text-gray-600">
            Ainda tem dúvidas?{" "}
            <a href="#" className="text-[#4fffbd] font-medium hover:underline">
              Entre em contato conosco
            </a>
          </p>
        </div>
      </div>
    </section>
  )
}
