import { DollarSign, TrendingUp, BarChart3, Search, Clock, Shield } from "lucide-react"

export default function Features() {
  return (
    <section id="features" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 relative inline-block">
            Por que escolher a MyListfy?
            <div className="absolute -bottom-2 left-0 right-0 h-1 bg-gradient-to-r from-[#4fffbd] to-[#88ffff] rounded-full"></div>
          </h2>
          <p className="text-lg text-gray-600">
            Economize tempo e dinheiro com nossa lista de produtos lucrativos para vender na Amazon dos EUA.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Feature 1 - Agora é economia com VAs */}
          <div className="bg-[#fff0df] rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:translate-y-[-8px] group">
            <div className="bg-gradient-to-r from-[#4fffbd] to-[#88ffff] w-12 h-12 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
              <DollarSign className="h-6 w-6 text-gray-800" />
            </div>
            <h3 className="text-xl font-bold mb-2">Economia com Virtual Assistants</h3>
            <p className="text-gray-600">
              Economize até $500 por mês em assistentes virtuais. Nossa lista substitui a necessidade de contratar VAs
              para pesquisa de produtos.
            </p>
          </div>

          {/* Feature 2 */}
          <div className="bg-[#fff0df] rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:translate-y-[-8px] group">
            <div className="bg-gradient-to-r from-[#4fffbd] to-[#88ffff] w-12 h-12 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
              <TrendingUp className="h-6 w-6 text-gray-800" />
            </div>
            <h3 className="text-xl font-bold mb-2">Alto ROI</h3>
            <p className="text-gray-600">
              Até 75% de ROI médio com nossos produtos, maximizando seu investimento e aumentando seus lucros.
            </p>
          </div>

          {/* Feature 3 */}
          <div className="bg-[#fff0df] rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:translate-y-[-8px] group">
            <div className="bg-gradient-to-r from-[#4fffbd] to-[#88ffff] w-12 h-12 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
              <BarChart3 className="h-6 w-6 text-gray-800" />
            </div>
            <h3 className="text-xl font-bold mb-2">Vendas Consistentes</h3>
            <p className="text-gray-600">
              Produtos com média de 100 vendas mensais e mínimo de 10 vendas, garantindo giro rápido do seu estoque.
            </p>
          </div>

          {/* Feature 4 */}
          <div className="bg-[#fff0df] rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:translate-y-[-8px] group">
            <div className="bg-gradient-to-r from-[#4fffbd] to-[#88ffff] w-12 h-12 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
              <Search className="h-6 w-6 text-gray-800" />
            </div>
            <h3 className="text-xl font-bold mb-2">Pesquisa Avançada</h3>
            <p className="text-gray-600">
              Nossa equipe utiliza ferramentas avançadas para encontrar os melhores produtos, eliminando a necessidade
              de softwares caros.
            </p>
          </div>

          {/* Feature 5 */}
          <div className="bg-[#fff0df] rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:translate-y-[-8px] group">
            <div className="bg-gradient-to-r from-[#4fffbd] to-[#88ffff] w-12 h-12 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
              <Clock className="h-6 w-6 text-gray-800" />
            </div>
            <h3 className="text-xl font-bold mb-2">Economia de Tempo</h3>
            <p className="text-gray-600">
              Economize horas diárias que seriam gastas com pesquisa de produtos ou gerenciando assistentes virtuais.
            </p>
          </div>

          {/* Feature 6 - Lucro Garantido (substituindo Suporte Exclusivo) */}
          <div className="bg-[#fff0df] rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:translate-y-[-8px] group">
            <div className="bg-gradient-to-r from-[#4fffbd] to-[#88ffff] w-12 h-12 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
              <Shield className="h-6 w-6 text-gray-800" />
            </div>
            <h3 className="text-xl font-bold mb-2">Lucro Garantido</h3>
            <p className="text-gray-600">
              Produtos com lucro médio de $12 e mínimo de $5, cuidadosamente selecionados pela nossa equipe.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
