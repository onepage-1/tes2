import NextImage from "next/image"
import { Mail, Phone, Instagram } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          <div>
            <NextImage
              src="/images/logo.png"
              alt="MyListfy Logo"
              width={240}
              height={70}
              className="h-16 w-auto mb-4 brightness-200"
            />
            <p className="text-gray-400 mb-4">
              Lista de produtos lucrativos para vendedores brasileiros na Amazon dos EUA.
            </p>
            <div className="flex space-x-4">
              <a
                href="https://instagram.com/mylistfy"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-[#4fffbd]"
              >
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-bold text-lg mb-4">Links Rápidos</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-gray-400 hover:text-[#4fffbd]">
                  Início
                </a>
              </li>
              <li>
                <a href="#features" className="text-gray-400 hover:text-[#4fffbd]">
                  Recursos
                </a>
              </li>
              <li>
                <a href="#benefits" className="text-gray-400 hover:text-[#4fffbd]">
                  Benefícios
                </a>
              </li>
              <li>
                <a href="#pricing" className="text-gray-400 hover:text-[#4fffbd]">
                  Preços
                </a>
              </li>
              <li>
                <a href="#faq" className="text-gray-400 hover:text-[#4fffbd]">
                  FAQ
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-lg mb-4">Recursos</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-gray-400 hover:text-[#4fffbd]">
                  Suporte
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-[#4fffbd]">
                  Área do Cliente
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-lg mb-4">Contato</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <Mail className="h-5 w-5 text-[#4fffbd] flex-shrink-0 mt-0.5" />
                <span className="text-gray-400">contato@mylistfy.com</span>
              </li>
              <li className="flex items-start gap-3">
                <Phone className="h-5 w-5 text-[#4fffbd] flex-shrink-0 mt-0.5" />
                <span className="text-gray-400">+1 (365) 892-5670</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 mt-8 text-center text-gray-500 text-sm">
          <p>&copy; {new Date().getFullYear()} MyListfy. Todos os direitos reservados.</p>
          <div className="flex justify-center space-x-6 mt-4">
            <a href="#" className="hover:text-[#4fffbd]">
              Termos de Uso
            </a>
            <a href="#" className="hover:text-[#4fffbd]">
              Política de Privacidade
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}
