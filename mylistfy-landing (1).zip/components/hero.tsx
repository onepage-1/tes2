export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-[#4fffbd]/15 to-[#88ffff]/15 pt-20 pb-16 md:pt-32 md:pb-24">
      <div className="absolute inset-0 bg-[url('/placeholder.svg?height=500&width=500')] bg-repeat opacity-5"></div>
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6 text-center md:text-left">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
              Com a MyListfy é{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#4fffbd] to-[#88ffff] animate-pulse">
                Menos Tempo e Mais Lucro
              </span>
            </h1>
            <p className="text-xl text-gray-700 max-w-lg mx-auto md:mx-0">
              Lista diária de produtos lucrativos para Online Arbitrage (FBA e FBM) para vendedores na Amazon US.
              Simplificada para você escolher, listar e lucrar!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
              <a
                href="#pricing"
                className="bg-gradient-to-r from-[#4fffbd] to-[#88ffff] text-gray-800 font-bold px-8 py-3 rounded-full shadow-lg hover:shadow-xl transition-all text-lg hover:scale-105 transform duration-200"
              >
                Começar Agora
              </a>
              <a
                href="#features"
                className="bg-white text-gray-800 font-medium px-8 py-3 rounded-full shadow border border-gray-200 hover:shadow-md transition-all text-lg hover:bg-gray-50"
              >
                Saiba Mais
              </a>
            </div>
          </div>
          <div className="relative">
            <div className="bg-[#fff0df] rounded-3xl p-6 shadow-2xl relative z-10 transform md:rotate-2 hover:rotate-0 transition-transform duration-500 hover:scale-105">
              <div className="absolute -top-3 -right-3 bg-gradient-to-r from-[#4fffbd] to-[#88ffff] text-gray-800 font-bold px-4 py-1 rounded-full text-sm shadow-md">
                Exclusivo
              </div>
              <h3 className="text-2xl font-bold mb-4">O que você recebe:</h3>
              <ul className="space-y-4">
                <li className="flex items-start gap-3">
                  <div className="bg-[#4fffbd] rounded-full p-1 mt-1">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 text-white"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                  <div>
                    <span className="font-bold">Lista diária</span> com produtos lucrativos
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="bg-[#4fffbd] rounded-full p-1 mt-1">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 text-white"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                  <div>
                    <span className="font-bold">$12 de lucro médio</span> por produto
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="bg-[#4fffbd] rounded-full p-1 mt-1">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 text-white"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                  <div>
                    <span className="font-bold">Até 75% de ROI</span> médio
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="bg-[#4fffbd] rounded-full p-1 mt-1">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 text-white"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                  <div>
                    <span className="font-bold">100 vendas mensais</span> em média
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="bg-[#4fffbd] rounded-full p-1 mt-1">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 text-white"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                  <div>
                    <span className="font-bold">Calculadora exclusiva</span> semelhante ao ASINZEN
                  </div>
                </li>
              </ul>
            </div>
            <div className="absolute -bottom-6 -left-6 w-64 h-64 bg-[#88ffff]/30 rounded-full blur-3xl -z-10 animate-pulse"></div>
            <div className="absolute -top-6 -right-6 w-64 h-64 bg-[#4fffbd]/30 rounded-full blur-3xl -z-10 animate-pulse"></div>
          </div>
        </div>
      </div>
    </section>
  )
}
