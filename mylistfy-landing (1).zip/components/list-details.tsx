"use client"

import { useState } from "react"
import {
  ChevronDown,
  ChevronUp,
  FileText,
  Link,
  ShoppingCart,
  DollarSign,
  BarChart,
  LineChart,
  Tag,
  Hash,
  Layers,
  Users,
  Package,
  MessageSquare,
} from "lucide-react"

export default function ListDetails() {
  const [isOpen, setIsOpen] = useState(false)

  const listItems = [
    { icon: <FileText className="h-5 w-5" />, title: "Nome do produto", description: "Descrição completa do item" },
    {
      icon: <Link className="h-5 w-5" />,
      title: "Link do fornecedor",
      description: "Acesso direto à página do produto",
    },
    { icon: <Link className="h-5 w-5" />, title: "Link da Amazon", description: "Acesso direto à página na Amazon" },
    { icon: <Hash className="h-5 w-5" />, title: "ASIN", description: "Identificador único do produto na Amazon" },
    {
      icon: <Layers className="h-5 w-5" />,
      title: "Categoria do produto",
      description: "Classificação do tipo de produto",
    },
    {
      icon: <ShoppingCart className="h-5 w-5" />,
      title: "Custo de compra",
      description: "Valor para adquirir o produto",
    },
    { icon: <Tag className="h-5 w-5" />, title: "Preço de venda", description: "Valor atual no marketplace" },
    { icon: <DollarSign className="h-5 w-5" />, title: "Lucro", description: "Ganho líquido estimado" },
    { icon: <BarChart className="h-5 w-5" />, title: "ROI", description: "Retorno sobre o investimento" },
    {
      icon: <LineChart className="h-5 w-5" />,
      title: "Histórico de preço",
      description: "Variação de preços ao longo do tempo",
    },
    { icon: <BarChart className="h-5 w-5" />, title: "Vendas estimadas", description: "Volume mensal de vendas" },
    {
      icon: <BarChart className="h-5 w-5" />,
      title: "Rank BSR atual",
      description: "Posição atual no ranking de vendas",
    },
    {
      icon: <LineChart className="h-5 w-5" />,
      title: "Rank BSR médio (90 dias)",
      description: "Média de posição nos últimos 90 dias",
    },
    {
      icon: <Users className="h-5 w-5" />,
      title: "Número de vendedores",
      description: "Quantidade de concorrentes no listing",
    },
    {
      icon: <Package className="h-5 w-5" />,
      title: "Estoque dos concorrentes",
      description: "Quantidade disponível com outros vendedores",
    },
    {
      icon: <MessageSquare className="h-5 w-5" />,
      title: "Observações",
      description: "Promoções, cupons e informações adicionais",
    },
  ]

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 relative inline-block">
              O que está incluído nas listas da MyListfy?
              <div className="absolute -bottom-2 left-0 right-0 h-1 bg-gradient-to-r from-[#4fffbd] to-[#88ffff] rounded-full"></div>
            </h2>
            <p className="text-lg text-gray-600 mt-4 mb-6">
              Nossas listas contêm todas as informações necessárias para você tomar decisões de compra inteligentes.
            </p>
          </div>

          <div className="bg-[#fff0df] rounded-3xl overflow-hidden shadow-lg">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="w-full flex items-center justify-between p-6 bg-gradient-to-r from-[#4fffbd]/20 to-[#88ffff]/20 border-b border-amber-200"
            >
              <h3 className="text-xl font-bold">Ver todos os detalhes incluídos na lista</h3>
              <div className="bg-white rounded-full p-2 shadow-md">
                {isOpen ? (
                  <ChevronUp className="h-6 w-6 text-[#4fffbd]" />
                ) : (
                  <ChevronDown className="h-6 w-6 text-[#4fffbd]" />
                )}
              </div>
            </button>

            <div
              className={`transition-all duration-500 ease-in-out overflow-hidden ${
                isOpen ? "max-h-[2000px] opacity-100" : "max-h-0 opacity-0"
              }`}
            >
              <div className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {listItems.map((item, index) => (
                    <div
                      key={index}
                      className="bg-white rounded-xl p-4 shadow-md hover:shadow-lg transition-all duration-300 hover:translate-y-[-4px] border border-gray-100"
                    >
                      <div className="flex items-start gap-3">
                        <div className="bg-gradient-to-r from-[#4fffbd] to-[#88ffff] rounded-full p-2 text-white">
                          {item.icon}
                        </div>
                        <div>
                          <h4 className="font-bold text-gray-800">{item.title}</h4>
                          <p className="text-sm text-gray-600">{item.description}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-6 text-center">
                  <p className="text-gray-600 italic">
                    Todas essas informações são atualizadas diariamente para garantir a precisão dos dados.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
