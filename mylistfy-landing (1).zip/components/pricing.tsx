import { Check } from "lucide-react"

export default function Pricing() {
  return (
    <section id="pricing" className="py-20 bg-gradient-to-br from-[#4fffbd]/15 to-[#88ffff]/15">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 relative inline-block">
            Planos de Assinatura
            <div className="absolute -bottom-2 left-0 right-0 h-1 bg-gradient-to-r from-[#4fffbd] to-[#88ffff] rounded-full"></div>
          </h2>
          <p className="text-lg text-gray-600 mb-6">
            Escolha o plano ideal para o seu negócio e comece a receber produtos lucrativos diariamente.
          </p>
          <div className="inline-block bg-[#fff0df] px-6 py-3 rounded-full text-sm font-bold border-2 border-amber-200 shadow-md animate-pulse">
            <span className="text-amber-700">⚠️ Máximo de 20 clientes por lista - Vagas limitadas!</span>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {/* Plano Mensal */}
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl hover:translate-y-[-8px] group">
            <div className="p-6 border-b">
              <h3 className="text-xl font-bold mb-2">Plano Mensal</h3>
              <div className="flex items-end gap-1 mb-4">
                <span className="text-4xl font-bold">$64,99</span>
                <span className="text-gray-500">/mês</span>
              </div>
              <p className="text-gray-600">Ideal para quem quer testar o serviço.</p>
            </div>
            <div className="p-6">
              <ul className="space-y-3">
                <li className="flex items-start gap-2">
                  <Check className="h-5 w-5 text-[#4fffbd] flex-shrink-0 mt-0.5" />
                  <span>Lista diária de produtos lucrativos</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="h-5 w-5 text-[#4fffbd] flex-shrink-0 mt-0.5" />
                  <span>Lucro médio de $12 por produto</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="h-5 w-5 text-[#4fffbd] flex-shrink-0 mt-0.5" />
                  <span>Até 75% de ROI médio</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="h-5 w-5 text-[#4fffbd] flex-shrink-0 mt-0.5" />
                  <span>Suporte por e-mail</span>
                </li>
              </ul>
              <a
                href="#"
                className="mt-6 block w-full py-3 px-4 bg-white border-2 border-[#4fffbd] text-center rounded-full font-medium hover:bg-[#4fffbd]/10 transition-colors group-hover:shadow-md"
              >
                Assinar Agora
              </a>
            </div>
          </div>

          {/* Plano Anual - AGORA NO MEIO */}
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden relative transform scale-105 z-10 transition-all duration-300 hover:shadow-2xl hover:translate-y-[-12px]">
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#4fffbd] to-[#88ffff]"></div>
            <div className="absolute top-0 right-0 bg-gradient-to-r from-[#4fffbd] to-[#88ffff] text-xs font-bold px-4 py-1 uppercase rounded-bl-lg">
              Mais Popular
            </div>
            <div className="p-6 border-b bg-gradient-to-r from-[#4fffbd]/20 to-[#88ffff]/20">
              <h3 className="text-xl font-bold mb-2">Plano Anual</h3>
              <div className="flex items-end gap-1 mb-4">
                <span className="text-4xl font-bold">$38,97</span>
                <span className="text-gray-500">/mês</span>
              </div>
              <p className="text-gray-600">Economize 41% em relação ao plano mensal.</p>
            </div>
            <div className="p-6">
              <ul className="space-y-3">
                <li className="flex items-start gap-2">
                  <div className="bg-gradient-to-r from-[#4fffbd] to-[#88ffff] rounded-full p-0.5">
                    <Check className="h-4 w-4 text-white" />
                  </div>
                  <span>Lista diária de produtos lucrativos</span>
                </li>
                <li className="flex items-start gap-2">
                  <div className="bg-gradient-to-r from-[#4fffbd] to-[#88ffff] rounded-full p-0.5">
                    <Check className="h-4 w-4 text-white" />
                  </div>
                  <span>Lucro médio de $12 por produto</span>
                </li>
                <li className="flex items-start gap-2">
                  <div className="bg-gradient-to-r from-[#4fffbd] to-[#88ffff] rounded-full p-0.5">
                    <Check className="h-4 w-4 text-white" />
                  </div>
                  <span>Até 75% de ROI médio</span>
                </li>
                <li className="flex items-start gap-2">
                  <div className="bg-gradient-to-r from-[#4fffbd] to-[#88ffff] rounded-full p-0.5">
                    <Check className="h-4 w-4 text-white" />
                  </div>
                  <span>Suporte VIP</span>
                </li>
                <li className="flex items-start gap-2">
                  <div className="bg-gradient-to-r from-[#4fffbd] to-[#88ffff] rounded-full p-0.5">
                    <Check className="h-4 w-4 text-white" />
                  </div>
                  <span>Acesso as listas de dias anteriores</span>
                </li>
                <li className="flex items-start gap-2">
                  <div className="bg-gradient-to-r from-[#4fffbd] to-[#88ffff] rounded-full p-0.5">
                    <Check className="h-4 w-4 text-white" />
                  </div>
                  <span>
                    <span className="font-bold text-amber-700">Calculadora exclusiva semelhante ao ASINZEN</span>{" "}
                    <span className="bg-yellow-100 text-yellow-800 text-xs font-medium px-2 py-0.5 rounded">
                      Economia de $12/mês
                    </span>
                  </span>
                </li>
              </ul>
              <a
                href="#"
                className="mt-6 block w-full py-3 px-4 bg-gradient-to-r from-[#4fffbd] to-[#88ffff] text-center rounded-full font-bold shadow-md hover:shadow-lg transition-all"
              >
                Assinar Agora
              </a>
            </div>
          </div>

          {/* Plano Semestral */}
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl hover:translate-y-[-8px] group">
            <div className="p-6 border-b">
              <h3 className="text-xl font-bold mb-2">Plano Semestral</h3>
              <div className="flex items-end gap-1 mb-4">
                <span className="text-4xl font-bold">$53,99</span>
                <span className="text-gray-500">/mês</span>
              </div>
              <p className="text-gray-600">Economize 23% em relação ao plano mensal.</p>
            </div>
            <div className="p-6">
              <ul className="space-y-3">
                <li className="flex items-start gap-2">
                  <Check className="h-5 w-5 text-[#4fffbd] flex-shrink-0 mt-0.5" />
                  <span>Lista diária de produtos lucrativos</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="h-5 w-5 text-[#4fffbd] flex-shrink-0 mt-0.5" />
                  <span>Lucro médio de $12 por produto</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="h-5 w-5 text-[#4fffbd] flex-shrink-0 mt-0.5" />
                  <span>Até 75% de ROI médio</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="h-5 w-5 text-[#4fffbd] flex-shrink-0 mt-0.5" />
                  <span>Suporte prioritário</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="h-5 w-5 text-[#4fffbd] flex-shrink-0 mt-0.5" />
                  <span>Acesso as listas de dias anteriores</span>
                </li>
              </ul>
              <a
                href="#"
                className="mt-6 block w-full py-3 px-4 bg-white border-2 border-[#4fffbd] text-center rounded-full font-medium hover:bg-[#4fffbd]/10 transition-colors group-hover:shadow-md"
              >
                Assinar Agora
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 text-center">
          <a href="#" className="inline-flex items-center text-[#4fffbd] hover:underline font-medium">
            Ver todos os detalhes dos planos
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" viewBox="0 0 20 20" fill="currentColor">
              <path
                fillRule="evenodd"
                d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z"
                clipRule="evenodd"
              />
            </svg>
          </a>
        </div>
      </div>
    </section>
  )
}
