"use client"

import { useState } from "react"
import { ChevronLeft, ChevronRight, Star } from "lucide-react"
import NextImage from "next/image"

export default function Reviews() {
  const [currentIndex, setCurrentIndex] = useState(0)

  const reviews = [
    {
      id: 1,
      name: "Carlos Silva",
      role: "Vendedor FBA",
      content:
        "A MyListfy transformou meu negócio na Amazon. Antes eu gastava horas procurando produtos e nem sempre encontrava boas oportunidades. Agora recebo diariamente produtos com alto potencial de lucro.",
      rating: 5,
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      id: 2,
      name: "Ana Oliveira",
      role: "Vendedora FBM",
      content:
        "Economizo muito tempo e dinheiro com a MyListfy. Não preciso mais pagar por softwares caros ou assistentes virtuais. Os produtos têm um ROI excelente e vendem muito bem.",
      rating: 5,
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      id: 3,
      name: "Marcos Santos",
      role: "Iniciante na Amazon",
      content:
        "Como iniciante, a MyListfy foi fundamental para meu sucesso. Encontrar produtos lucrativos era meu maior desafio, mas agora recebo uma lista pronta todos os dias. Recomendo a todos!",
      rating: 5,
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      id: 4,
      name: "Juliana Costa",
      role: "Vendedora FBM",
      content:
        "Já vendo na Amazon há 3 anos e a MyListfy elevou meu negócio a outro nível. Os produtos têm margens excelentes e o suporte é incrível quando tenho dúvidas.",
      rating: 5,
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      id: 5,
      name: "Roberto Almeida",
      role: "Vendedor FBA",
      content:
        "A qualidade dos leads é impressionante. Já testei outras listas, mas a MyListfy é superior em todos os aspectos. O ROI médio de 75% é um diferencial.",
      rating: 5,
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      id: 6,
      name: "Fernanda Lima",
      role: "Vendedora FBA",
      content:
        "Meu faturamento aumentou 40% desde que comecei a usar a MyListfy. Os produtos vendem rapidamente e o lucro médio de $12 por item faz toda a diferença no final do mês.",
      rating: 5,
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      id: 7,
      name: "Pedro Mendes",
      role: "Vendedor FBA",
      content:
        "Como brasileiro vendendo nos EUA, enfrentava muitos desafios para encontrar produtos. A MyListfy resolveu esse problema e agora posso escalar meu negócio com confiança.",
      rating: 5,
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      id: 8,
      name: "Luciana Ferreira",
      role: "Vendedora FBM",
      content:
        "Mesmo vendendo sem me dedicar tanto, consigo resultados excelentes com a MyListfy. A lista economiza meu tempo limitado e me permite focar apenas em comprar e vender e fazer um extra.",
      rating: 5,
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      id: 9,
      name: "Gabriel Moreira",
      role: "Vendedor FBA e FBM",
      content:
        "Utilizo os leads tanto para FBA quanto para FBM e os resultados são consistentes em ambos os modelos. A MyListfy entende as necessidades dos vendedores brasileiros na Amazon EUA.",
      rating: 5,
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      id: 10,
      name: "Camila Rocha",
      role: "Vendedora FBA",
      content:
        "A MyListfy é um investimento que se paga rapidamente. Com o primeiro lote de produtos que comprei da lista, já recuperei o valor anual da assinatura. Simplesmente incrível!",
      rating: 5,
      image: "/placeholder.svg?height=100&width=100",
    },
  ]

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 3 >= reviews.length ? 0 : prevIndex + 3))
  }

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 3 < 0 ? Math.max(0, reviews.length - 3) : prevIndex - 3))
  }

  const visibleReviews = [
    reviews[currentIndex],
    reviews[(currentIndex + 1) % reviews.length],
    reviews[(currentIndex + 2) % reviews.length],
  ]

  return (
    <section id="reviews" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">O que nossos clientes dizem</h2>
          <p className="text-lg text-gray-600">
            Veja como a MyListfy está ajudando vendedores brasileiros a terem sucesso na Amazon dos EUA.
          </p>
        </div>

        <div className="relative">
          <div className="grid md:grid-cols-3 gap-6">
            {visibleReviews.map((review) => (
              <div key={review.id} className="bg-[#fff0df] rounded-xl p-6 shadow-lg">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 rounded-full overflow-hidden bg-gray-200">
                    <NextImage
                      src={review.image || "/placeholder.svg"}
                      alt={review.name}
                      width={48}
                      height={48}
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold">{review.name}</h4>
                    <p className="text-sm text-gray-500">{review.role}</p>
                  </div>
                </div>
                <div className="mb-4">
                  <div className="flex text-yellow-400 mb-2">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-700">{review.content}</p>
                </div>
              </div>
            ))}
          </div>

          <button
            onClick={prevSlide}
            className="absolute -left-4 md:-left-12 top-1/2 transform -translate-y-1/2 bg-white rounded-full p-2 shadow-lg hover:bg-gray-100"
          >
            <ChevronLeft className="h-6 w-6" />
          </button>

          <button
            onClick={nextSlide}
            className="absolute -right-4 md:-right-12 top-1/2 transform -translate-y-1/2 bg-white rounded-full p-2 shadow-lg hover:bg-gray-100"
          >
            <ChevronRight className="h-6 w-6" />
          </button>
        </div>

        <div className="flex justify-center mt-8">
          {[...Array(Math.ceil(reviews.length / 3))].map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrentIndex(i * 3)}
              className={`w-3 h-3 mx-1 rounded-full ${currentIndex === i * 3 ? "bg-[#4fffbd]" : "bg-gray-300"}`}
            />
          ))}
        </div>
      </div>
    </section>
  )
}
