import NextImage from "next/image"

export default function Suppliers() {
  return (
    <section id="suppliers" className="py-20 bg-gradient-to-br from-[#4fffbd]/10 to-[#88ffff]/10">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 relative inline-block">
            Mais de 1200 Fornecedores
            <div className="absolute -bottom-2 left-0 right-0 h-1 bg-gradient-to-r from-[#4fffbd] to-[#88ffff] rounded-full"></div>
          </h2>
          <p className="text-lg text-gray-600 mb-8">
            Trabalhamos com os maiores e mais confiáveis fornecedores do mercado para garantir os melhores produtos para
            você.
          </p>
        </div>

        <div className="relative overflow-hidden rounded-3xl bg-white shadow-xl p-8 md:p-12">
          {/* Efeito de gradiente no topo */}
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#4fffbd] to-[#88ffff]"></div>

          {/* Contador de fornecedores */}
          <div className="bg-gradient-to-r from-[#4fffbd]/20 to-[#88ffff]/20 rounded-2xl p-6 mb-12 text-center">
            <h3 className="text-5xl font-bold mb-2 bg-clip-text text-transparent bg-gradient-to-r from-[#4fffbd] to-[#88ffff]">
              1200+
            </h3>
            <p className="text-xl text-gray-700">Fornecedores disponíveis para maximizar suas oportunidades</p>
          </div>

          {/* Logos dos fornecedores */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8 items-center justify-items-center">
            {/* Walmart */}
            <div className="bg-white rounded-xl p-4 shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105 w-full max-w-[150px] h-[80px] flex items-center justify-center">
              <NextImage
                src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/ca/Walmart_logo.svg/1280px-Walmart_logo.svg.png"
                alt="Walmart"
                width={100}
                height={30}
                className="object-contain"
              />
              <span className="sr-only">Walmart</span>
            </div>

            {/* Target - Ajustada para ficar dentro do espaço */}
            <div className="bg-white rounded-xl p-4 shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105 w-full max-w-[150px] h-[80px] flex items-center justify-center">
              <NextImage
                src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Target_Corporation_logo_%28vector%29.svg/1200px-Target_Corporation_logo_%28vector%29.svg.png"
                alt="Target"
                width={50}
                height={50}
                className="object-contain"
              />
              <span className="sr-only">Target</span>
            </div>

            {/* Vitacost - Link atualizado */}
            <div className="bg-white rounded-xl p-4 shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105 w-full max-w-[150px] h-[80px] flex items-center justify-center">
              <NextImage
                src="https://www.jasedlak.com/wp-content/uploads/2022/01/logo-vitacost-success-story-480x220.png"
                alt="Vitacost"
                width={100}
                height={50}
                className="object-contain"
              />
              <span className="sr-only">Vitacost</span>
            </div>

            {/* PerfumesClub - Link atualizado */}
            <div className="bg-white rounded-xl p-4 shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105 w-full max-w-[150px] h-[80px] flex items-center justify-center">
              <NextImage
                src="https://play-lh.googleusercontent.com/b5GlbArQ7sJNE4W9WvLmci8DsCHmXYn9rJw3zJxuKus5UT1L5QIlkUyjBA8_F7YBVw"
                alt="PerfumesClub"
                width={70}
                height={70}
                className="object-contain"
              />
              <span className="sr-only">PerfumesClub</span>
            </div>

            {/* ToyShnip - Link atualizado */}
            <div className="bg-white rounded-xl p-4 shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105 w-full max-w-[150px] h-[80px] flex items-center justify-center">
              <NextImage
                src="https://media.licdn.com/dms/image/v2/C4E0BAQHSfbV875VELg/company-logo_200_200/company-logo_200_200/0/1630621249700/toyshnip_logo?e=2147483647&v=beta&t=dsc-gE5l7kFAwwsBAWja-VXXDV9ZKnkrhHIXdiJxX4Y"
                alt="ToyShnip"
                width={70}
                height={70}
                className="object-contain"
              />
              <span className="sr-only">ToyShnip</span>
            </div>
          </div>

          {/* Texto adicional */}
          <div className="text-center mt-12">
            <p className="text-lg text-gray-600">
              E muitos outros fornecedores confiáveis para diversificar seu inventário e maximizar seus lucros.
            </p>
            <div className="mt-6 inline-block bg-[#fff0df] px-6 py-3 rounded-full text-sm font-bold border border-amber-200">
              <span className="text-amber-700">Acesso a todos os fornecedores com qualquer plano de assinatura!</span>
            </div>
          </div>

          {/* Efeito de gradiente */}
          <div className="absolute -bottom-10 -right-10 w-64 h-64 bg-[#4fffbd]/20 rounded-full blur-3xl -z-10"></div>
          <div className="absolute -top-10 -left-10 w-64 h-64 bg-[#88ffff]/20 rounded-full blur-3xl -z-10"></div>
        </div>
      </div>
    </section>
  )
}
