import { History, Shield, Users, Package, Store, Zap } from "lucide-react"

export default function UniqueFeatures() {
  const features = [
    {
      icon: <History className="h-8 w-8" />,
      title: "Verificação do Histórico de Preços",
      description:
        "Analisamos oportunidades de arbitragem online utilizando o gráfico de preços da Amazon, com notas de 90 e 30 dias indicando leads confiavelmente lucrativos e com potencial de ganhar o buybox, com base nos preços mais baixos de venda.",
    },
    {
      icon: <Shield className="h-8 w-8" />,
      title: "Verificação de Reclamações de Propriedade Intelectual (IP)",
      description:
        "Verificamos o histórico do Keepa para identificar rotações de vendedores. Uma boa rotação de vendedores significa que não há um ou dois vendedores que suprimem a oferta. Além disso, monitoramos o alerta de IP para relatórios legítimos.",
    },
    {
      icon: <Users className="h-8 w-8" />,
      title: "Análise da Concorrência",
      description:
        "A planilha inclui informações sobre o número de vendedores FBA e os estoques de concorrentes que estão vendendo o mesmo produto a preços dentro de $1 do seu. Isso ajuda a verificar rapidamente a concorrência e entender como seu preço se compara ao dos outros vendedores.",
    },
    {
      icon: <Package className="h-8 w-8" />,
      title: "Sem Produtos Perigosos, Frágeis ou de Tamanho Excepcional",
      description:
        "Não incluímos itens químicos ou frágeis em nossas listas. Além disso, todos os produtos têm tamanho adequado, o que significa que os custos de envio serão razoáveis.",
    },
    {
      icon: <Store className="h-8 w-8" />,
      title: "Não Vendido pela Amazon",
      description:
        "Queremos informar que a Amazon não venderá os produtos da lista, agora ou em breve, o que significa que você não precisará competir com a Amazon. Além disso, esses leads têm chance de ganhar o buybox.",
    },
    {
      icon: <Zap className="h-8 w-8" />,
      title: "Acesso Imediato aos Produtos",
      description:
        "Com a sua assinatura, você tem acesso imediato aos produtos do mês anterior. Não há necessidade de esperar pelos produtos diários; comece a encontrar oportunidades e utilizar nosso serviço agora mesmo.",
    },
  ]

  return (
    <section className="py-20 bg-gradient-to-br from-[#4fffbd]/15 to-[#88ffff]/15">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 relative inline-block">
            Características que só a MyListfy oferece
            <div className="absolute -bottom-2 left-0 right-0 h-1 bg-gradient-to-r from-[#4fffbd] to-[#88ffff] rounded-full"></div>
          </h2>
          <p className="text-lg text-gray-600 mt-4">
            Diferenciais exclusivos que fazem da MyListfy a melhor opção para vendedores na Amazon.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:translate-y-[-8px] group relative overflow-hidden"
            >
              {/* Gradiente no topo */}
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#4fffbd] to-[#88ffff]"></div>

              <div className="bg-gradient-to-r from-[#4fffbd]/20 to-[#88ffff]/20 w-16 h-16 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                <div className="text-[#4fffbd]">{feature.icon}</div>
              </div>

              <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
